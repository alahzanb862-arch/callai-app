package com.example.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.sqrt

private const val TAG = "CallAudioEngine"
private const val SAMPLE_RATE = 16000

class CallAudioEngine(context: Context) {
    private val appContext = context.applicationContext
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _micLevel = MutableStateFlow(0f)
    val micLevel: StateFlow<Float> = _micLevel.asStateFlow()

    private val _isRecordingVoiceCommand = MutableStateFlow(false)
    val isRecordingVoiceCommand: StateFlow<Boolean> = _isRecordingVoiceCommand.asStateFlow()

    private var monitorJob: Job? = null
    private var audioRecord: AudioRecord? = null

    @Volatile
    private var capturingCommand = false
    private val commandPcmStream = ByteArrayOutputStream()

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val arResult = tts?.setLanguage(Locale("ar"))
                if (arResult == TextToSpeech.LANG_MISSING_DATA || arResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
                ttsReady = true
            }
        }
    }

    fun configureCallAudio(speakerOn: Boolean, muted: Boolean) {
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = speakerOn
            audioManager.isMicrophoneMute = muted
        } catch (e: Exception) {
            Log.w(TAG, "AudioManager config warning: ${e.message}")
        }
    }

    fun resetCallAudio() {
        try {
            audioManager.isMicrophoneMute = false
            @Suppress("DEPRECATION")
            audioManager.isSpeakerphoneOn = false
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) {
            Log.w(TAG, "AudioManager reset warning: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun startMicMonitor(scope: CoroutineScope) {
        if (monitorJob?.isActive == true) return
        monitorJob = scope.launch(Dispatchers.IO) {
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
            ).coerceAtLeast(2048)

            val recorder = try {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf * 2,
                )
            } catch (e: Exception) {
                Log.w(TAG, "AudioRecord unavailable: ${e.message}")
                return@launch
            }

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                return@launch
            }

            audioRecord = recorder
            val shortBuf = ShortArray(minBuf / 2)
            try {
                recorder.startRecording()
                while (isActive) {
                    val readCount = recorder.read(shortBuf, 0, shortBuf.size)
                    if (readCount > 0) {
                        var sumSquares = 0.0
                        for (i in 0 until readCount) {
                            val s = shortBuf[i].toDouble()
                            sumSquares += s * s
                        }
                        val rms = sqrt(sumSquares / readCount) / 16000.0
                        _micLevel.value = rms.toFloat().coerceIn(0f, 1f)

                        if (capturingCommand) {
                            val byteBuffer = ByteBuffer.allocate(readCount * 2).order(ByteOrder.LITTLE_ENDIAN)
                            for (i in 0 until readCount) {
                                byteBuffer.putShort(shortBuf[i])
                            }
                            synchronized(commandPcmStream) {
                                // Cap voice command at ~18 seconds (~576KB)
                                if (commandPcmStream.size() < 576_000) {
                                    commandPcmStream.write(byteBuffer.array())
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Mic monitor loop ended: ${e.message}")
            } finally {
                try {
                    recorder.stop()
                } catch (_: Exception) {
                }
                recorder.release()
                audioRecord = null
                _micLevel.value = 0f
            }
        }
    }

    fun startVoiceCommandCapture() {
        synchronized(commandPcmStream) {
            commandPcmStream.reset()
        }
        capturingCommand = true
        _isRecordingVoiceCommand.value = true
    }

    fun stopVoiceCommandCaptureAsWav(): ByteArray? {
        capturingCommand = false
        _isRecordingVoiceCommand.value = false
        val pcmBytes = synchronized(commandPcmStream) {
            val out = commandPcmStream.toByteArray()
            commandPcmStream.reset()
            out
        }
        // Require at least ~0.25s of audio
        if (pcmBytes.size < 8000) return null
        return wrapPcmInWav(pcmBytes, SAMPLE_RATE, 1, 16)
    }

    fun speakText(text: String) {
        if (!ttsReady) return
        val clean = text.replace("*", "").replace("#", "").take(1500)
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "callai_tts_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun stopAll() {
        capturingCommand = false
        _isRecordingVoiceCommand.value = false
        monitorJob?.cancel()
        monitorJob = null
        resetCallAudio()
        stopSpeaking()
    }

    fun release() {
        stopAll()
        tts?.shutdown()
        tts = null
    }

    private fun wrapPcmInWav(
        pcmData: ByteArray,
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int,
    ): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * channels * bitsPerSample / 8
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1.toShort())
            putShort(channels.toShort())
            putInt(sampleRate)
            putInt(byteRate)
            putShort((channels * bitsPerSample / 8).toShort())
            putShort(bitsPerSample.toShort())
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()
        return header + pcmData
    }
}
