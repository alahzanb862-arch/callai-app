package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald & Acoustic Cyan Palette
val EmeraldGlow = Color(0xFF00E676)
val EmeraldDeep = Color(0xFF00A884)
val EmeraldContainerDark = Color(0xFF0A3D2E)
val CyanSpark = Color(0xFF00E5FF)
val CyanContainerDark = Color(0xFF08343E)
val AiViolet = Color(0xFF7C4DFF)

// Obsidian Dark Surfaces (WhatsApp-inspired luxury dark)
val ObsidianBg = Color(0xFF0B141A)
val ObsidianSurface = Color(0xFF111B21)
val ObsidianSurfaceHigh = Color(0xFF1F2C34)
val ObsidianSurfaceElevated = Color(0xFF233138)
val ObsidianOutline = Color(0xFF2A3942)
val TextPrimaryDark = Color(0xFFE9EDEF)
val TextSecondaryDark = Color(0xFF8696A0)

// Chat Bubble Colors
val SentBubbleDark = Color(0xFF005C4B)
val ReceivedBubbleDark = Color(0xFF202C33)
val AiBubbleDark = Color(0xFF102A3A)

// Light Palette
val LightBg = Color(0xFFF4F8F6)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceHigh = Color(0xFFEBF2EE)
val EmeraldLightPrimary = Color(0xFF00875A)
val CyanLightSecondary = Color(0xFF00838F)
val SentBubbleLight = Color(0xFFD9FDD3)
val ReceivedBubbleLight = Color(0xFFFFFFFF)
val AiBubbleLight = Color(0xFFE3F6FA)

// Semantic Status Colors
val CallAcceptGreen = Color(0xFF25D366)
val CallEndRed = Color(0xFFFF3B30)
val WarningAmber = Color(0xFFFFB300)
