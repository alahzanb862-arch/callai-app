package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiAssistantRepository
import com.example.data.model.CallEvent
import com.example.data.model.CallMode
import com.example.data.model.CallSession
import com.example.data.model.PrivateUser
import com.example.data.model.UiState
import com.example.data.repository.CallRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "ActiveCallVM"

class ActiveCallViewModel(
    private val callRepo: CallRepository,
    private val aiRepo: GeminiAssistantRepository,
    private val callId: String,
    private val currentUserId: String,
) : ViewModel() {

    val callState: StateFlow<UiState<CallSession?>> =
        callRepo.observeCall(callId, currentUserId)
            .map<CallSession?, UiState<CallSession?>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, "Call observe error", root)
                emit(UiState.Error(root.message ?: "تعذر الاتصال بالمكالمة"))
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val eventsState: StateFlow<List<CallEvent>> =
        callRepo.observeCallEvents(callId, currentUserId)
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                Log.w(TAG, "Call events error", firestoreError ?: error)
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _aiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val aiState: StateFlow<AiUiState> = _aiState.asStateFlow()

    private val _shareAiWithFriend = MutableStateFlow(true)
    val shareAiWithFriend: StateFlow<Boolean> = _shareAiWithFriend.asStateFlow()

    private val _speakAiAloud = MutableStateFlow(true)
    val speakAiAloud: StateFlow<Boolean> = _speakAiAloud.asStateFlow()

    fun setShareAiWithFriend(enabled: Boolean) {
        _shareAiWithFriend.value = enabled
    }

    fun setSpeakAiAloud(enabled: Boolean) {
        _speakAiAloud.value = enabled
    }

    fun endCall() {
        viewModelScope.launch {
            callRepo.endCall(callId)
        }
    }

    fun toggleVideoMode(currentMode: CallMode) {
        val next = if (currentMode == CallMode.VIDEO) CallMode.AUDIO else CallMode.VIDEO
        viewModelScope.launch {
            callRepo.toggleCallMode(callId, next)
        }
    }

    fun askAiInCallText(
        prompt: String,
        sender: PrivateUser,
        onFinishedText: (String) -> Unit = {},
    ) {
        val clean = prompt.trim()
        if (clean.isEmpty()) return
        val call = (callState.value as? UiState.Success)?.data
        val friendName = call?.calleeName ?: "صديقك"
        val participantUids = call?.participantUids ?: listOf(currentUserId)
        val events = eventsState.value

        viewModelScope.launch {
            _aiState.value = AiUiState.Loading
            var latest = ""
            try {
                aiRepo.askInCallTextStream(clean, friendName, events).collect { chunk ->
                    latest = chunk
                    _aiState.value = AiUiState.Streaming(chunk)
                }
                if (latest.isNotBlank()) {
                    _aiState.value = AiUiState.Success(latest)
                    if (_shareAiWithFriend.value && call != null) {
                        callRepo.shareAiAnswerInCall(callId, participantUids, sender, clean, latest)
                    }
                    onFinishedText(latest)
                } else {
                    _aiState.value = AiUiState.Error("لم يتم استلام إجابة من AI")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiState.value = AiUiState.Error(e.localizedMessage ?: "حدث خطأ في مساعد AI")
            }
        }
    }

    fun askAiInCallVoice(
        wavBytes: ByteArray,
        sender: PrivateUser,
        onFinishedText: (String) -> Unit = {},
    ) {
        val call = (callState.value as? UiState.Success)?.data
        val friendName = call?.calleeName ?: "صديقك"
        val participantUids = call?.participantUids ?: listOf(currentUserId)
        val events = eventsState.value
        val recentCtx = events.takeLast(6).joinToString("\n") { "${it.senderName}: ${it.content}" }

        viewModelScope.launch {
            _aiState.value = AiUiState.Loading
            var latest = ""
            try {
                aiRepo.askWithAudioStream(
                    wavBytes = wavBytes,
                    contextHeader = "أنت الآن مساعد ذكي داخل مكالمة حية مع $friendName. سياق المكالمة:\n$recentCtx",
                ).collect { chunk ->
                    latest = chunk
                    _aiState.value = AiUiState.Streaming(chunk)
                }
                if (latest.isNotBlank()) {
                    _aiState.value = AiUiState.Success(latest)
                    if (_shareAiWithFriend.value && call != null) {
                        callRepo.shareAiAnswerInCall(callId, participantUids, sender, "سؤال صوتي 🎙️", latest)
                    }
                    onFinishedText(latest)
                } else {
                    _aiState.value = AiUiState.Error("تعذر فهم الأمر الصوتي")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiState.value = AiUiState.Error(e.localizedMessage ?: "تعذر معالجة الصوت")
            }
        }
    }
}
