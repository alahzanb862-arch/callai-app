package com.example.data.ai

import android.util.Log
import com.example.data.model.CallEvent
import com.example.data.model.ChatMessage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "GeminiAssistant"

class GeminiAssistantRepository {

    private val chatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    "أنت مساعد CallAI الذكي المدمج داخل تطبيق محادثة ومكالمات. " +
                        "تفهم سياق المحادثة والمكالمة بدقة، وتقدم إجابات عملية واضحة ومباشرة بنفس لغة المستخدم (العربية أو الإنجليزية). " +
                        "عند حل الأسئلة أو تلخيص المحادثات أو اقتراح الردود، كن مختصراً ومفيداً ومنظماً.",
                )
            },
        )
    }

    private val smartRepliesModel by lazy {
        val schema = Schema.obj(
            properties = mapOf(
                "replies" to Schema.array(
                    items = Schema.string(),
                    description = "Three short, natural reply suggestions matching the conversation language and tone",
                ),
            ),
        )
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = schema
            },
        )
    }

    fun askInChatStream(
        userPrompt: String,
        recentMessages: List<ChatMessage>,
        chatTitle: String,
    ): Flow<String> = flow {
        val contextBlock = formatChatContext(recentMessages)
        val fullPrompt = buildString {
            appendLine("اسم المحادثة/المجموعة: $chatTitle")
            appendLine("سياق أحدث الرسائل:")
            appendLine(contextBlock)
            appendLine()
            appendLine("طلب المستخدم الآن:")
            appendLine(userPrompt)
        }
        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                chatModel.generateContentStream(fullPrompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("لم يُرجع الذكاء الاصطناعي أي نص.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Chat AI timed out", e)
            throw IllegalStateException("انتهت مهلة الذكاء الاصطناعي (60 ثانية). حاول مجدداً.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Chat AI failed", e)
            throw e
        }
    }

    fun summarizeChatStream(
        recentMessages: List<ChatMessage>,
        chatTitle: String,
    ): Flow<String> = askInChatStream(
        userPrompt = "لخّص أهم النقاط والقرارات والأسئلة المفتوحة في هذه المحادثة بنقاط واضحة ومختصرة.",
        recentMessages = recentMessages,
        chatTitle = chatTitle,
    )

    suspend fun suggestReplies(recentMessages: List<ChatMessage>): Result<List<String>> {
        if (recentMessages.isEmpty()) {
            return Result.success(
                listOf(
                    "أهلاً! كيف حالك اليوم؟",
                    "هل يناسبك نتكلم مكالمة الآن؟",
                    "تم، سأتابع معك فوراً.",
                ),
            )
        }
        val contextBlock = formatChatContext(recentMessages.takeLast(12))
        val prompt = "اقترح 3 ردود قصيرة وطبيعية ومناسبة للرد على آخر رسالة في المحادثة التالية:\n$contextBlock"
        return try {
            val response = withTimeout(45_000L) {
                smartRepliesModel.generateContent(prompt)
            }
            val rawJson = response.text ?: throw IllegalStateException("رد فارغ من النموذج")
            val json = JSONObject(rawJson)
            val arr = json.getJSONArray("replies")
            val replies = (0 until arr.length()).mapNotNull { idx ->
                arr.optString(idx).trim().takeIf { it.isNotEmpty() }
            }.take(3)
            Result.success(replies)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Smart replies timed out", e)
            Result.failure(IllegalStateException("انتهت مهلة اقتراح الردود."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Smart replies failed", e)
            Result.failure(e)
        }
    }

    fun askInCallTextStream(
        userPrompt: String,
        friendName: String,
        recentEvents: List<CallEvent>,
    ): Flow<String> = flow {
        val callContext = formatCallContext(recentEvents)
        val fullPrompt = buildString {
            appendLine("أنت الآن داخل مكالمة حية بين المستخدم وصديقه ($friendName).")
            appendLine("المستخدم ضغط على زر AI لطلب المساعدة الفورية أثناء المكالمة.")
            if (callContext.isNotBlank()) {
                appendLine("سياق المكالمة والأسئلة السابقة:")
                appendLine(callContext)
            }
            appendLine()
            appendLine("السؤال أو الطلب:")
            appendLine(userPrompt)
            appendLine("أجب بوضوح وسرعة وبأسلوب مناسب للقراءة والاستماع أثناء المكالمة.")
        }
        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                chatModel.generateContentStream(fullPrompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("لم يُرجع الذكاء الاصطناعي إجابة.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "In-call text AI timed out", e)
            throw IllegalStateException("انتهت مهلة الذكاء الاصطناعي.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "In-call text AI failed", e)
            throw e
        }
    }

    fun askWithAudioStream(
        wavBytes: ByteArray,
        contextHeader: String,
    ): Flow<String> = flow {
        val promptContent = content {
            inlineData(wavBytes, "audio/wav")
            text(
                "$contextHeader\nاستمع للأمر الصوتي أو السؤال في هذا التسجيل، ثم أجب عليه مباشرة وبوضوح بنفس اللغة المستخدمة في الصوت.",
            )
        }
        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                chatModel.generateContentStream(promptContent).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("تعذر فهم الصوت أو لم يتم إرجاع إجابة.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Audio AI timed out", e)
            throw IllegalStateException("انتهت مهلة تحليل الصوت.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Audio AI failed", e)
            throw e
        }
    }

    private fun formatChatContext(messages: List<ChatMessage>): String {
        if (messages.isEmpty()) return "(لا توجد رسائل سابقة بعد)"
        return messages.takeLast(18).joinToString("\n") { msg ->
            "[${msg.senderName}]: ${msg.text}"
        }
    }

    private fun formatCallContext(events: List<CallEvent>): String {
        if (events.isEmpty()) return ""
        return events.takeLast(10).joinToString("\n") { evt ->
            "[${evt.senderName} - ${evt.eventType}]: ${evt.content}"
        }
    }
}
