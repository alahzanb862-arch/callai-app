import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.TaskAction
import java.util.Base64

// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.kotlin.compose) apply false
  alias(libs.plugins.google.devtools.ksp) apply false
  alias(libs.plugins.secrets) apply false
  alias(libs.plugins.google.services) apply false
}

abstract class EnsureDebugKeystoreTask : DefaultTask() {
  @get:Internal
  abstract val keystoreFile: RegularFileProperty

  @get:Internal
  abstract val base64File: RegularFileProperty

  @TaskAction
  fun ensure() {
    val keystore = keystoreFile.get().asFile
    if (keystore.exists()) return

    keystore.parentFile?.mkdirs()
    val b64 = base64File.get().asFile
    if (b64.exists()) {
      val cleaned = b64.readText().replace(Regex("\\s+"), "")
      if (cleaned.isNotEmpty()) {
        keystore.writeBytes(Base64.getDecoder().decode(cleaned))
        logger.lifecycle("Restored debug.keystore from debug.keystore.base64")
        return
      }
    }

    val keytoolBin = "${System.getProperty("java.home")}/bin/keytool"
    val process = ProcessBuilder(
      keytoolBin,
      "-genkeypair",
      "-v",
      "-keystore", keystore.absolutePath,
      "-storepass", "android",
      "-alias", "androiddebugkey",
      "-keypass", "android",
      "-keyalg", "RSA",
      "-keysize", "2048",
      "-validity", "10000",
      "-dname", "CN=Android Debug,O=Android,C=US",
    ).inheritIO().start()
    val exitCode = process.waitFor()
    if (exitCode != 0 || !keystore.exists()) {
      error("Failed to generate fallback debug.keystore (exitCode=$exitCode)")
    }
    logger.lifecycle("Generated fallback debug.keystore at ${keystore.absolutePath}")
  }
}

val ensureDebugKeystore = tasks.register<EnsureDebugKeystoreTask>("ensureDebugKeystore") {
  keystoreFile.set(layout.projectDirectory.file("debug.keystore"))
  base64File.set(layout.projectDirectory.file("debug.keystore.base64"))
}

subprojects {
  tasks.matching { it.name == "validateSigningDebug" }.configureEach {
    dependsOn(ensureDebugKeystore)
  }
}
